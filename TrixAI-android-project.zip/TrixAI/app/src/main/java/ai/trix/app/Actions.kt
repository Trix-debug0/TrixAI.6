package ai.trix.app

import android.Manifest
import android.app.Activity
import android.app.PendingIntent
import android.content.*
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.AlarmClock
import android.provider.ContactsContract.CommonDataKinds.Phone
import android.provider.Settings
import android.telephony.SmsManager
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.*

/** One-shot sensitive action. ACTION CREATED -> CONFIRMATION -> EXECUTION; a second execute() is refused. */
class Confirm(private val run: () -> String) {
    val id: String = UUID.randomUUID().toString()
    private var used = false
    @Synchronized fun execute(): String {
        if (used) return "That action was already handled."
        used = true
        return try { run() } catch (e: Exception) { "I couldn't complete that action." }
    }
}

class Outcome(
    val say: String, val confirm: Confirm? = null, val perm: String? = null,
    val listenNext: Boolean = false, val lang: String = "en"
)

class Actions(private val ctx: Context, private val say: (String) -> Unit) {
    private val main = Handler(Looper.getMainLooper())

    private fun has(p: String) = ContextCompat.checkSelfPermission(ctx, p) == PackageManager.PERMISSION_GRANTED
    private fun launch(i: Intent): Boolean = try { ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); true } catch (e: Exception) { false }
    private fun start(i: Intent, ok: String, bad: String) = if (launch(i)) Outcome(ok) else Outcome(bad)
    private fun clock(h: Int, m: Int) = "%d:%02d %s".format(if (h % 12 == 0) 12 else h % 12, m, if (h < 12) "AM" else "PM")

    fun run(c: Cmd): Outcome = try { dispatch(c) } catch (e: Exception) { Outcome("I couldn't complete that action.") }

    private fun dispatch(c: Cmd): Outcome = when (c.intent) {
        "OPEN_APP" -> openApp(c.app)
        "CALL_CONTACT" -> withContact(c) { n, num -> call(n, num) }
        "CALL_NUMBER" -> {
            val n = c.number.filter { it.isDigit() || it == '+' }
            when {
                n.length < 3 -> Outcome("I didn't catch the number.", listenNext = true)
                !has(Manifest.permission.CALL_PHONE) -> Outcome("I need phone permission to place calls.", perm = Manifest.permission.CALL_PHONE)
                else -> Outcome("I'm about to call $n. Should I continue?", confirm = Confirm { placeCall(n, n) })
            }
        }
        "SEND_SMS" -> if (c.message.isBlank()) Outcome("What should the message say?", listenNext = true) else withContact(c) { n, num ->
            if (!has(Manifest.permission.SEND_SMS)) Outcome("I need SMS permission to send messages.", perm = Manifest.permission.SEND_SMS)
            else Outcome("SMS to $n: ${c.message}. Send?", confirm = Confirm { sendSms(n, num, c.message) })
        }
        "SEND_WHATSAPP" -> if (c.message.isBlank()) Outcome("What should the message say?", listenNext = true) else withContact(c) { n, num ->
            if (!num.trim().startsWith("+")) Outcome("$n's number has no country code, so I can't open the WhatsApp chat reliably.")
            else Outcome("WhatsApp message to $n: ${c.message}. Send?", confirm = Confirm { sendWhatsApp(n, num, c.message) })
        }
        "SEARCH_YOUTUBE" -> view("https://www.youtube.com/results?search_query=" + Uri.encode(c.query), "com.google.android.youtube", "Searching YouTube for ${c.query}.")
        "SEARCH_WEB" -> view("https://www.google.com/search?q=" + Uri.encode(c.query), null, "Searching for ${c.query}.")
        "NAVIGATE" -> view("google.navigation:q=" + Uri.encode(c.location), "com.google.android.apps.maps", "Starting navigation to ${c.location}.")
        "FIND_PLACE" -> view("geo:0,0?q=" + Uri.encode(c.query.ifBlank { c.location }), "com.google.android.apps.maps", "Searching Maps for ${c.query.ifBlank { c.location }}.")
        "SET_ALARM" -> start(
            Intent(AlarmClock.ACTION_SET_ALARM).putExtra(AlarmClock.EXTRA_HOUR, c.hour)
                .putExtra(AlarmClock.EXTRA_MINUTES, c.minute).putExtra(AlarmClock.EXTRA_SKIP_UI, true),
            "Alarm set for ${clock(c.hour, c.minute)}.", "I couldn't set the alarm."
        )
        "SET_TIMER" -> if (c.seconds <= 0) Outcome("How long should the timer run?", listenNext = true) else start(
            Intent(AlarmClock.ACTION_SET_TIMER).putExtra(AlarmClock.EXTRA_LENGTH, c.seconds).putExtra(AlarmClock.EXTRA_SKIP_UI, true),
            "Timer started.", "I couldn't start the timer."
        )
        "FLASHLIGHT_ON" -> torch(true)
        "FLASHLIGHT_OFF" -> torch(false)
        "VOLUME_UP", "VOLUME_DOWN" -> {
            val up = c.intent == "VOLUME_UP"
            ctx.getSystemService(AudioManager::class.java).adjustStreamVolume(
                AudioManager.STREAM_MUSIC, if (up) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI
            )
            Outcome(if (up) "Volume increased." else "Volume decreased.")
        }
        "VOLUME_SET" -> {
            val am = ctx.getSystemService(AudioManager::class.java)
            val p = c.value.coerceIn(0, 100)
            am.setStreamVolume(AudioManager.STREAM_MUSIC, am.getStreamMaxVolume(AudioManager.STREAM_MUSIC) * p / 100, AudioManager.FLAG_SHOW_UI)
            Outcome("Volume set to $p percent.")
        }
        "GET_BATTERY" -> Outcome("Your battery is ${ctx.getSystemService(BatteryManager::class.java).getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)} percent.")
        "GET_TIME" -> Outcome("It is " + SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date()) + ".")
        "GET_DATE" -> Outcome("Today is " + SimpleDateFormat("EEEE, d MMMM yyyy", Locale.getDefault()).format(Date()) + ".")
        "OPEN_SETTINGS" -> {
            val q = c.query.lowercase()
            val a = when {
                "wi" in q -> Settings.ACTION_WIFI_SETTINGS
                "blue" in q -> Settings.ACTION_BLUETOOTH_SETTINGS
                "access" in q -> Settings.ACTION_ACCESSIBILITY_SETTINGS
                else -> Settings.ACTION_SETTINGS
            }
            start(Intent(a), "Opening settings.", "I couldn't open settings.")
        }
        "READ_SCREEN" -> a11y { Outcome(it.readScreen()) }
        "CLICK_ELEMENT" -> a11y { if (it.clickByText(c.query)) Outcome("Pressed ${c.query}.") else Outcome("I couldn't find ${c.query} on this screen.") }
        "SCROLL_DOWN" -> a11y { if (it.scroll(true)) Outcome("Scrolled down.") else Outcome("I couldn't scroll here.") }
        "SCROLL_UP" -> a11y { if (it.scroll(false)) Outcome("Scrolled up.") else Outcome("I couldn't scroll here.") }
        "GO_BACK" -> a11y { if (it.back()) Outcome("Going back.") else Outcome("I couldn't go back.") }
        "GO_HOME" -> a11y { if (it.home()) Outcome("Going home.") else Outcome("I couldn't go home.") }
        "GENERAL_AI", "UNSUPPORTED" -> Outcome(c.reply.ifBlank { "I can't do that yet." }, lang = c.lang)
        else -> Outcome("I can't do that yet.")
    }

    private fun a11y(f: (TrixAccessibilityService) -> Outcome): Outcome {
        val s = TrixAccessibilityService.instance
        if (s == null) {
            launch(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            return Outcome("I need accessibility access for this. I'm opening Accessibility Settings. Please turn on Trix AI.")
        }
        return f(s)
    }

    private fun openApp(name: String): Outcome {
        val pm = ctx.packageManager
        val q = name.trim().lowercase()
        if (q.isBlank()) return Outcome("Which app should I open?", listenNext = true)
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        val hit = apps.firstOrNull { it.loadLabel(pm).toString().lowercase() == q }
            ?: apps.firstOrNull { it.loadLabel(pm).toString().lowercase().contains(q) }
            ?: return Outcome("That application is not installed.")
        val i = pm.getLaunchIntentForPackage(hit.activityInfo.packageName) ?: return Outcome("I couldn't open $name.")
        return if (launch(i)) Outcome("Opening ${hit.loadLabel(pm)}.") else Outcome("I couldn't open $name.")
    }

    private fun view(url: String, pkg: String?, ok: String): Outcome {
        for (p in listOf(pkg, null)) {
            val i = Intent(Intent.ACTION_VIEW, Uri.parse(url))
            if (p != null) i.setPackage(p)
            if (launch(i)) return Outcome(ok)
            if (pkg == null) break
        }
        return Outcome("I couldn't open that.")
    }

    private fun torch(on: Boolean): Outcome {
        val cm = ctx.getSystemService(CameraManager::class.java)
        val id = cm.cameraIdList.firstOrNull { cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true }
            ?: return Outcome("This phone has no flashlight.")
        cm.setTorchMode(id, on)
        return Outcome(if (on) "Flashlight on." else "Flashlight off.")
    }

    private fun withContact(c: Cmd, then: (String, String) -> Outcome): Outcome {
        if (c.person.isBlank()) return Outcome("Who do you mean?", listenNext = true)
        if (!has(Manifest.permission.READ_CONTACTS)) return Outcome("I need contacts permission to find ${c.person}.", perm = Manifest.permission.READ_CONTACTS)
        val hits = LinkedHashMap<String, String>()
        ctx.contentResolver.query(
            Phone.CONTENT_URI, arrayOf(Phone.DISPLAY_NAME, Phone.NUMBER),
            "${Phone.DISPLAY_NAME} LIKE ?", arrayOf("%${c.person}%"), null
        )?.use { while (it.moveToNext()) hits.putIfAbsent(it.getString(0), it.getString(1)) }
        return when {
            hits.isEmpty() -> Outcome("I couldn't find a contact named ${c.person}.")
            hits.size > 1 -> Outcome("I found ${hits.size} contacts: ${hits.keys.take(4).joinToString(", ")}. Which one do you mean?", listenNext = true)
            else -> hits.entries.first().let { then(it.key, it.value) }
        }
    }

    private fun call(label: String, n: String): Outcome {
        if (!has(Manifest.permission.CALL_PHONE)) return Outcome("I need phone permission to place calls.", perm = Manifest.permission.CALL_PHONE)
        return Outcome(placeCall(label, n))
    }

    private fun placeCall(label: String, n: String) =
        if (launch(Intent(Intent.ACTION_CALL, Uri.parse("tel:" + Uri.encode(n))))) "Calling $label." else "I couldn't place the call."

    @Suppress("DEPRECATION")
    private fun sendSms(name: String, num: String, text: String): String {
        val sm = if (Build.VERSION.SDK_INT >= 31) ctx.getSystemService(SmsManager::class.java) else SmsManager.getDefault()
        val act = "ai.trix.app.SMS_SENT." + UUID.randomUUID()
        val rec = object : BroadcastReceiver() {
            override fun onReceive(x: Context, y: Intent) {
                ctx.unregisterReceiver(this)
                say(if (resultCode == Activity.RESULT_OK) "SMS sent to $name." else "I couldn't send the SMS to $name.")
            }
        }
        ContextCompat.registerReceiver(ctx, rec, IntentFilter(act), ContextCompat.RECEIVER_NOT_EXPORTED)
        val pi = PendingIntent.getBroadcast(ctx, 0, Intent(act).setPackage(ctx.packageName), PendingIntent.FLAG_IMMUTABLE)
        val parts = sm.divideMessage(text)
        sm.sendMultipartTextMessage(num, null, parts, ArrayList<PendingIntent>(parts.map { pi }), null)
        return "Sending SMS to $name."
    }

    private fun sendWhatsApp(name: String, num: String, text: String): String {
        val d = num.filter { it.isDigit() }
        val i = Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/" + d + "?text=" + Uri.encode(text))).setPackage("com.whatsapp")
        if (!launch(i)) return "I couldn't open WhatsApp."
        main.postDelayed({
            val ok = TrixAccessibilityService.instance?.clickByText("Send") == true
            say(if (ok) "I pressed Send in WhatsApp." else "Your message is ready in WhatsApp, but I couldn't press Send. Please turn on accessibility access or tap Send.")
        }, 3000)
        return "Opening WhatsApp chat with $name."
    }
}
