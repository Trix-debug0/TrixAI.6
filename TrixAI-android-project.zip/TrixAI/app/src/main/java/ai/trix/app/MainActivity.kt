package ai.trix.app

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.os.*
import android.speech.*
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.view.*
import android.widget.*
import java.util.*
import java.util.concurrent.Executors

class MicView(c: Context) : View(c) {
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    var active = false
        set(v) { field = v; invalidate() }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat(); val cx = w / 2
        val fg = if (active) Color.BLACK else Color.WHITE
        ring.color = Color.WHITE; ring.strokeWidth = w * 0.025f
        fill.color = if (active) Color.WHITE else Color.BLACK
        c.drawCircle(cx, h / 2, w / 2 - ring.strokeWidth, fill)
        c.drawCircle(cx, h / 2, w / 2 - ring.strokeWidth, ring)
        ring.color = fg; ring.strokeWidth = w * 0.03f; fill.color = fg
        c.drawRoundRect(cx - w * 0.07f, h * 0.27f, cx + w * 0.07f, h * 0.55f, w * 0.07f, w * 0.07f, fill)
        c.drawArc(cx - w * 0.13f, h * 0.38f, cx + w * 0.13f, h * 0.62f, 0f, 180f, false, ring)
        c.drawLine(cx, h * 0.62f, cx, h * 0.70f, ring)
        c.drawLine(cx - w * 0.07f, h * 0.70f, cx + w * 0.07f, h * 0.70f, ring)
    }
}

class MainActivity : Activity() {
    private val a11yIntents = setOf("READ_SCREEN", "CLICK_ELEMENT", "SCROLL_DOWN", "SCROLL_UP", "GO_BACK", "GO_HOME")
    private val main = Handler(Looper.getMainLooper())
    private val io = Executors.newSingleThreadExecutor()
    private val brain = Brain()
    private lateinit var statusView: TextView
    private lateinit var mic: MicView
    private lateinit var langBtn: TextView
    private lateinit var actions: Actions
    private var tts: TextToSpeech? = null
    private var recognizer: SpeechRecognizer? = null
    private var pending: Confirm? = null
    private var busy = false
    private var langIdx = 0
    private val langs = listOf("Auto Detect", "English", "Hindi", "Urdu")
    private val tags = listOf("en-IN", "en-IN", "hi-IN", "ur-PK")

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val prefs = getSharedPreferences("trix", MODE_PRIVATE)
        langIdx = prefs.getInt("lang", 0)
        actions = Actions(this) { msg -> main.post { brain.noteSpoken(msg); speak(msg) } }
        buildUi()
        tts = TextToSpeech(this) { st ->
            if (st == TextToSpeech.SUCCESS && !prefs.getBoolean("welcomed", false)) {
                prefs.edit().putBoolean("welcomed", true).apply()
                speak("Welcome to Trix AI. Your voice can control your phone. Tap the microphone and speak.")
            }
        }
    }

    private fun buildUi() {
        val d = resources.displayMetrics.density
        fun px(v: Int) = (v * d).toInt()
        fun label(t: String, size: Float, color: Int) = TextView(this).apply {
            text = t; textSize = size; setTextColor(color); gravity = Gravity.CENTER
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            setBackgroundColor(Color.BLACK); setPadding(px(24), px(24), px(24), px(24))
        }
        root.addView(label("Trix AI", 36f, Color.WHITE).apply { typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL) })
        root.addView(label("Your Voice. Your Phone. Your Freedom.", 14f, 0xFF9E9E9E.toInt()))
        mic = MicView(this).apply {
            layoutParams = LinearLayout.LayoutParams(px(220), px(220)).apply { topMargin = px(48); bottomMargin = px(32) }
            contentDescription = "Microphone. Double tap to speak to Trix AI."
            isClickable = true; isFocusable = true
            setOnClickListener { onMic() }
        }
        root.addView(mic)
        statusView = label("Tap to speak", 22f, Color.WHITE).apply { accessibilityLiveRegion = View.ACCESSIBILITY_LIVE_REGION_POLITE }
        root.addView(statusView)
        langBtn = label("", 16f, Color.WHITE).apply {
            minHeight = px(56); setPadding(px(24), px(12), px(24), px(12))
            background = GradientDrawable().apply { setStroke(px(2), Color.WHITE); cornerRadius = px(28).toFloat() }
            isClickable = true; isFocusable = true
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = px(48) }
            setOnClickListener {
                langIdx = (langIdx + 1) % langs.size
                getSharedPreferences("trix", MODE_PRIVATE).edit().putInt("lang", langIdx).apply()
                refreshLang(); speak(langs[langIdx])
            }
        }
        refreshLang(); root.addView(langBtn)
        setContentView(root)
    }

    private fun refreshLang() {
        langBtn.text = "Voice Language: " + langs[langIdx]
        langBtn.contentDescription = "Voice language, " + langs[langIdx] + ". Double tap to change."
    }

    private fun setState(t: String, active: Boolean) {
        statusView.text = t; mic.active = active
        if (t != "Tap to speak") mic.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
    }

    private fun onMic() {
        if (busy) return
        tts?.stop()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            speak("First, I need microphone permission so I can hear your commands.")
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1)
            return
        }
        listen()
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        val ok = res.isNotEmpty() && res[0] == PackageManager.PERMISSION_GRANTED
        if (code == 1) { if (ok) listen() else speak("I can't hear you without microphone permission.") }
        else speak(if (ok) "Permission granted. Please repeat your request." else "Permission denied. I can't do that without it.")
    }

    private fun listen() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { speak("Speech recognition is not available on this phone."); return }
        busy = true
        setState("Listening...", true)
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onResults(r: Bundle?) {
                    val t = r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                    if (t.isNullOrBlank()) fail("I didn't hear anything. Tap to try again.") else handle(t)
                }
                override fun onError(e: Int) {
                    fail(when (e) {
                        SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "I didn't hear anything. Tap to try again."
                        SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Internet connection is unavailable."
                        else -> "Speech recognition failed. Please try again."
                    })
                }
                override fun onReadyForSpeech(p: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(v: Float) {}
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(p: Bundle?) {}
                override fun onEvent(t: Int, p: Bundle?) {}
            })
            startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, tags[langIdx])
                if (langIdx == 0 && Build.VERSION.SDK_INT >= 33) {
                    putExtra(RecognizerIntent.EXTRA_ENABLE_LANGUAGE_DETECTION, true)
                    putStringArrayListExtra(RecognizerIntent.EXTRA_LANGUAGE_DETECTION_ALLOWED_LANGUAGES, arrayListOf("en-IN", "hi-IN", "ur-PK"))
                }
            })
        }
    }

    private fun handle(text: String) {
        pending?.let { p ->
            pending = null
            when (yesNo(text)) {
                true -> { setState("Working...", false); done(p.execute()); return }
                false -> { done("Cancelled."); return }
                null -> {}
            }
        }
        setState("Thinking...", false)
        io.execute {
            val r = brain.interpret(text, langs[langIdx])
            main.post {
                r.fold(
                    onSuccess = { act(it) },
                    onFailure = { err -> val o = offline(text); if (o != null) act(o) else fail(errText(err)) }
                )
            }
        }
    }

    private fun act(c: Cmd) {
        setState("Working...", false)
        if (c.intent in a11yIntents && TrixAccessibilityService.instance != null) {
            moveTaskToBack(true)
            main.postDelayed({ execute(c) }, 900)
        } else execute(c)
    }

    private fun execute(c: Cmd) {
        val o = actions.run(c)
        if (o.perm != null) { fail(o.say); requestPermissions(arrayOf(o.perm), 2); return }
        pending = o.confirm
        done(o.say, o.confirm != null || o.listenNext, o.lang)
    }

    private fun done(msg: String, listenAfter: Boolean = false, lang: String = "en") {
        busy = false
        brain.noteSpoken(msg)
        setState(if (listenAfter) "Waiting for your answer..." else "Done", false)
        speak(msg, lang, listenAfter)
        if (!listenAfter) main.postDelayed({ if (!busy) setState("Tap to speak", false) }, 3000)
    }

    private fun fail(msg: String) {
        busy = false
        setState("Tap to speak", false)
        speak(msg)
    }

    private fun speak(text: String, lang: String = "en", listenAfter: Boolean = false) {
        val t = tts ?: return
        val loc = when (lang) { "hi" -> Locale("hi", "IN"); "ur" -> Locale("ur", "PK"); else -> Locale("en", "IN") }
        if (t.setLanguage(loc) < 0) t.setLanguage(Locale.ENGLISH)
        t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) {}
            override fun onError(id: String?) {}
            override fun onDone(id: String?) { if (listenAfter) main.post { if (!busy) listen() } }
        })
        t.speak(text, TextToSpeech.QUEUE_FLUSH, null, "trix-" + System.nanoTime())
    }

    private fun yesNo(t: String): Boolean? {
        val w = t.lowercase().split(Regex("[\\s,.!?\u0964\u06D4]+")).filter { it.isNotEmpty() }
        val no = setOf("no", "nope", "cancel", "stop", "don't", "dont", "nahi", "nahin", "mat", "नहीं", "नही", "रुको", "نہیں", "نہ", "رکو")
        val yes = setOf("yes", "yeah", "yep", "sure", "ok", "okay", "send", "confirm", "continue", "haan", "han", "ji", "theek", "thik", "हाँ", "हां", "जी", "ठीक", "ہاں", "جی", "ٹھیک")
        return when { w.any { it in no } -> false; w.any { it in yes } -> true; else -> null }
    }

    private fun offline(t: String): Cmd? {
        val s = t.lowercase()
        val i = when {
            "battery" in s || "बैटरी" in s -> "GET_BATTERY"
            "time" in s || "samay" in s -> "GET_TIME"
            "date" in s -> "GET_DATE"
            "flashlight" in s || "torch" in s -> if ("off" in s || "band" in s) "FLASHLIGHT_OFF" else "FLASHLIGHT_ON"
            else -> return null
        }
        return Cmd(i)
    }

    private fun errText(e: Throwable) = when {
        e.message?.contains("key is missing") == true -> "The Gemini API key is missing from this build."
        e is java.io.IOException -> "Internet connection is unavailable. I can still tell you the time, date and battery, and control the flashlight."
        e.message?.contains("Gemini error") == true -> "The AI service returned an error. Please try again."
        else -> "I couldn't understand that. Please try again."
    }

    override fun onDestroy() {
        recognizer?.destroy(); tts?.shutdown(); io.shutdown()
        super.onDestroy()
    }
}
