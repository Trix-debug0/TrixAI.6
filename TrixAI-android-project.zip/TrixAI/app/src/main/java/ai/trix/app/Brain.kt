package ai.trix.app

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

data class Cmd(
    val intent: String, val app: String = "", val person: String = "", val number: String = "",
    val message: String = "", val query: String = "", val hour: Int = 0, val minute: Int = 0,
    val seconds: Int = 0, val location: String = "", val value: Int = 0, val lang: String = "en", val reply: String = ""
)

class Brain {
    private val history = ArrayList<Pair<String, String>>()

    fun noteSpoken(t: String) {
        if (history.isEmpty()) return
        val l = history.removeAt(history.lastIndex)
        history.add(l.first to l.second + "\n[Spoken to user: " + t + "]")
    }

    private fun JSONObject.s(k: String) = if (isNull(k)) "" else optString(k)

    fun interpret(userText: String, langHint: String): Result<Cmd> = runCatching {
        if (BuildConfig.GEMINI_API_KEY.isBlank()) error("key is missing")
        val contents = JSONArray()
        fun add(role: String, text: String) {
            contents.put(JSONObject().put("role", role).put("parts", JSONArray().put(JSONObject().put("text", text))))
        }
        history.takeLast(8).forEach { add(it.first, it.second) }
        add("user", userText)
        val body = JSONObject()
            .put("system_instruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", SYSTEM + " Language preference: " + langHint + "."))))
            .put("contents", contents)
            .put("generationConfig", JSONObject().put("temperature", 0.2).put("responseMimeType", "application/json"))
        val url = "https://generativelanguage.googleapis.com/v1beta/models/" + BuildConfig.GEMINI_MODEL + ":generateContent"
        val conn = (URL(url).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"; connectTimeout = 10000; readTimeout = 20000; doOutput = true
            setRequestProperty("Content-Type", "application/json")
            setRequestProperty("x-goog-api-key", BuildConfig.GEMINI_API_KEY)
        }
        conn.outputStream.use { it.write(body.toString().toByteArray()) }
        val code = conn.responseCode
        val resp = (if (code in 200..299) conn.inputStream else conn.errorStream).bufferedReader().use { it.readText() }
        if (code !in 200..299) error("Gemini error " + code)
        val text = JSONObject(resp).getJSONArray("candidates").getJSONObject(0)
            .getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
        val j = JSONObject(text.trim().removePrefix("```json").removeSuffix("```").trim())
        history.add("user" to userText); history.add("model" to text)
        while (history.size > 16) history.removeAt(0)
        Cmd(
            intent = j.s("intent").ifBlank { "UNSUPPORTED" }, app = j.s("app"), person = j.s("person"),
            number = j.s("number"), message = j.s("message"), query = j.s("query"),
            hour = j.optInt("hour"), minute = j.optInt("minute"), seconds = j.optInt("seconds"),
            location = j.s("location"), value = j.optInt("value"), lang = j.s("lang").ifBlank { "en" }, reply = j.s("reply")
        )
    }

    companion object {
        const val SYSTEM = """You are the intent engine of Trix AI, a voice assistant for blind users. The user speaks English, Hindi, Hinglish or Urdu (Urdu may be in Urdu script). Reply with ONE JSON object only: {"intent":string,"app":string,"person":string,"number":string,"message":string,"query":string,"hour":int,"minute":int,"seconds":int,"location":string,"value":int,"lang":"en|hi|ur","reply":string}. Intents: OPEN_APP, CALL_CONTACT, CALL_NUMBER, SEND_SMS, SEND_WHATSAPP, SEARCH_YOUTUBE, SEARCH_WEB, SET_ALARM, SET_TIMER, NAVIGATE, FIND_PLACE, FLASHLIGHT_ON, FLASHLIGHT_OFF, VOLUME_UP, VOLUME_DOWN, VOLUME_SET, GET_BATTERY, GET_TIME, GET_DATE, OPEN_SETTINGS, READ_SCREEN, CLICK_ELEMENT, SCROLL_DOWN, SCROLL_UP, GO_BACK, GO_HOME, GENERAL_AI, UNSUPPORTED. Rules: write app names and person names in Latin script as an Android app label or saved contact would appear (WhatsApp, YouTube, Rahul). hour is 24-hour time. seconds is the total timer length. value is a volume percent. For OPEN_SETTINGS put wifi, bluetooth or accessibility in query. lang is the language the user spoke. For GENERAL_AI, reply is the full answer in that language (Devanagari script for Hindi or Hinglish). For UNSUPPORTED, reply is one short sentence in that language saying you cannot do that yet. Use UNSUPPORTED for anything not covered, including reminders, payments, banking, deleting data. Never claim an action is done. Never invent contacts or phone numbers."""
    }
}
