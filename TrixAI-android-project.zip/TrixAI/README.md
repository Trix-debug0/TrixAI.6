# Trix AI (core build)

Voice -> Android SpeechRecognizer -> Gemini (JSON intent) -> action executor -> TextToSpeech.

## Build on a computer
1. Open this folder in Android Studio (JDK 17).
2. Create `local.properties` next to `settings.gradle.kts` and add: `GEMINI_API_KEY=your_new_key`
   (optional: `GEMINI_MODEL=gemini-2.5-flash`). Never commit this file.
3. Run on a real phone. Emulators have poor speech and no real contacts/SMS.

## Build from a phone (no PC)
Push to a private GitHub repo, add a repository secret named `GEMINI_API_KEY`, open Actions -> Build APK -> download the artifact.

## After install
Settings -> Accessibility -> Trix AI -> turn on (needed for read screen, click, scroll, WhatsApp Send).
